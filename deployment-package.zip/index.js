const url = process.env.url;
const apiKey = process.env.apiKey;
const bucketname = process.env.bucketname;
const filename = process.env.filename;
const request = require('request-promise');
const AWS = require('aws-sdk');
const s3 = new AWS.S3();

exports.handler = async (event) => {

    var options = {
        uri: url,
        encoding: 'utf-8',
        headers: (apiKey != "NOT_APPLICABLE") ? {
            'Authorization': apiKey
        } : {}
    };

    return request(options)
        .then(body => s3.putObject({
                Body: body,
                Key: filename,
                Bucket: bucketname
            }).promise()

        );
};